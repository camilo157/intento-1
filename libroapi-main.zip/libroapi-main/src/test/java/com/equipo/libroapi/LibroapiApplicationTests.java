package com.equipo.libroapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibroapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
